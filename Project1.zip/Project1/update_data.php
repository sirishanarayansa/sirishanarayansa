<?php include('config.php');

$param = $_POST['param'];
$primary_keys = $_POST['primary_keys'];
$data = $_POST['data'];
$sql = '';

if ($param == 'student')
{
	$student_number =  $data['student_number'];
    $name = $data['name'];
    $class =  $data['class'];
    $major = $data['major'];

    $sql = "UPDATE `student` SET 
    			`student_number`=$student_number, 
    			`name`='$name', 
    			`class`='$class',
    			`major`='$major'
    		WHERE student_number=".$primary_keys['student_number'];
}
else if ($param == 'course')
{
    $course_number =  $data['course_number'];
    $course_name = $data['course_name'];
    $credit_hours =  $data['credit_hours'];
    $department = $data['department'];

    $sql = "UPDATE course SET 
    			`course_number`='$course_number',
        		`course_name`='$course_name',
        		`credit_hours`='$credit_hours',
        		`department`='$department'  
        	WHERE course_number='".$primary_keys['course_number']."'";
}
else if ($param == 'section')
{
	$section_identifier =  $data['section_identifier'];
    $course_number = $data['course_number'];
    $semester = $data['semester'];
    $year =  $data['year'];
    $instructor = $data['instructor'];

    $sql = "UPDATE section SET 
    			`section_identifier`=$section_identifier,
    			`course_number`='$course_number',
    			`semester`='$semester',
    			`year`='$year',
    			`instructor`='$instructor' 
    		WHERE section_identifier=".$primary_keys['section_identifier'];
}
else if ($param == 'grade_report')
{
	$student_number =  $data['student_number'];
    $section_identifier = $data['section_identifier'];
    $grade =  $data['grade'];

    $sql = "UPDATE `grade_report` SET 
    			`student_number`=$student_number,
    			`section_identifier`=$section_identifier,
    			`grade`='$grade'
    		WHERE student_number='".$primary_keys['student_number']."' and 
    			section_identifier = '".$primary_keys['section_identifier']."'";
}
else if ($param == 'prerequisite')
{
	$course_number =  $data['course_number'];
    $prerequisite_number = $data['prerequisite_number'];

    $sql = "UPDATE prerequisite SET 
    			`course_number`='$course_number',
    			`prerequisite_number`='$prerequisite_number' 
    		WHERE course_number='".$primary_keys['course_number']."' and prerequisite_number='".$primary_keys['prerequisite_number']."'";
}
if($sql!=''){
	mysqli_query($con,$sql);
}
closedbconnection($con);
?>