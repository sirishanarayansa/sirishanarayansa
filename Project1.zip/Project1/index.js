function editRow(rowIndex){
	closeAllEditRows();
	$('#row_id_'+rowIndex+' .col_data').hide();
	$('#row_id_'+rowIndex+' .col_edit').hide();
	$('#row_id_'+rowIndex+' .col_input').show();
	$('#row_id_'+rowIndex+' .col_update').show();
}

function closeAllEditRows(){
	$('.col_data').show();
	$('.col_edit').show();
	$('.col_input').hide();
	$('.col_update').hide();
}

function onUpdate(param, rowIndex){
	let payload = {
		param: param, 
		primary_keys: {},
		data: {}
	};
	var primary_keys = document.querySelectorAll('#row_id_'+rowIndex+' .primary_key');
	for(let key=0; key<primary_keys.length;key++){
		payload['primary_keys'][primary_keys[key].querySelector('input[name="header"]').value] = primary_keys[key].querySelector('input[name="column"]').value;
	}

	let cols = $('#row_id_'+rowIndex+' .col_input input[type=text]');
	for(let i=0; i<cols.length;i++){
		payload['data'][cols[i].name] = cols[i].value;
	}
    $.ajax({
        type: "POST",
        url: SITEURL+'/update_data.php',
        data: payload, // serializes the form's elements.
        success: function(data)
        {
        	closeAllEditRows();
        	$('#row_id_'+rowIndex+' .col_data').text(function(index){
        		console.log(cols[index]);
				return cols[index].value;
			});
        }
    });
}