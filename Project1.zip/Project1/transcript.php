<?php include("header.php");
$query 	= "
			SELECT 
				s.name,
				sc.course_number,
				g.grade,
				sc.semester, 
				sc.year, 
				g.section_identifier 
			FROM 
				student s 
			INNER JOIN 
				grade_report g 
			ON 
				s.student_number = g.student_number 
			INNER JOIN 
				section sc 
			ON 
				g.section_identifier = sc.section_identifier 
			ORDER BY 
				s.name ASC;";
$result	= getAllRows(mysqli_query($con, $query));
closedbconnection($con);
$final_result = array();
foreach($result as $key => $value){
	if (array_key_exists($value->name,$final_result)){
		array_push($final_result[$value->name],$value);
	}else{
		$final_result[$value->name] = array($value);
	}	
}
?>
	<table class="transcript_table">
		<thead>
			<tr>
				<th rowspan="2">Student_name</th>
				<th colspan="5">Student_transcript</th>
			</tr>
			<tr>
				<th>Course_number</th>
				<th>Grade</th>
				<th>Semester</th>
				<th>Year</th>
				<th>Section_id</th>
			</tr>
		</thead>
		<tbody>
			<?php 
			$counter =1;
			foreach($final_result as $key => $value){
				foreach($value as $innerKey => $innerValue){?>
					<tr>
						<?php if($counter==1){?>
							<td rowspan="<?php echo count($value)?>">
								<?php echo $key;?>						
							</td>
						<?php }?>
						<td><?php echo $innerValue->course_number;?></td>
						<td><?php echo $innerValue->grade;?></td>
						<td><?php echo $innerValue->semester;?></td>
						<td><?php echo $innerValue->year;?></td>
						<td><?php echo $innerValue->section_identifier;?></td>
					</tr>
					<?php 
					if($counter==count($value)){
						$counter = 1;
					}else{
						$counter++;
					}
				}
			}?>
		</tbody>
	</table>
</body>
</html>