<?php  
define("SITEURL","http://".$_SERVER["HTTP_HOST"]."/project1/");
$currentFile			=	$_SERVER['REQUEST_URI'];
$parts					=	explode('/', $currentFile);
$page_name				=	$parts[count($parts) - 1];
$firstfilename			=	$parts[2];
$con					=	mysqli_connect('localhost','root','','universitydb');
$connection			    =	mysqli_select_db($con,'universitydb');

function getAllRows($res)
{
    while($rows=@mysqli_fetch_object($res)) 
    {
        $values[]			=	$rows;
    }
    return $values;
 }

function getCount($con, $query)
{
    $res                    =   @mysqli_query($con,$query); 
    $cnt                    =   @mysqli_num_rows($res);  
    return $cnt;
}

function closedbconnection($con)
{
	mysqli_close($con);
}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>