<?php include('config.php');?>
<!DOCTYPE html>
<html>
<head>
  <title>University</title>
  <script>
    const SITEURL = "<?php echo SITEURL;?>";
  </script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="index.js"></script>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
<center>
	<hr size="5" color ="black">
<h1>University of Missouri St Louis </h1>
<left><div class = "tabs">
	<div class ="tabs__sidebar">
		<a href="<?php echo SITEURL; ?>" class="tabs__button <?php  echo ($firstfilename=='index.php' || $firstfilename=='')?'active_tab':''; ?>">Home</a>&nbsp;
		<a href ="<?php echo SITEURL; ?>transcript.php" class ="tabs__button <?php  echo ($firstfilename=='transcript.php')?'active_tab':''; ?>">Transcript</a>
	</div>
</div>
<hr size="5" color ="black">
</left>
