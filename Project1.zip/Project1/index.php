<?php 
include("header.php");
$err_msg = '';
$param 		=  'student';
if (isset($_GET['tab'])){  
	$param 	=   $_GET['tab'] ;      
} 
$cols = mysqli_query($con, "SHOW COLUMNS FROM ".$param );
$primary_keys = array();
if($param == 'student'){
	$primary_keys[] = 'student_number';
}else if($param == 'course'){
	$primary_keys[] = 'course_number';
}else if($param == 'section'){
	$primary_keys[] = 'section_identifier';
}else if($param == 'grade_report'){
	$primary_keys[] = 'student_number';
	$primary_keys[] = 'section_identifier';
}else if($param == 'prerequisite'){
	$primary_keys[] = 'course_number';
	$primary_keys[] = 'prerequisite_number';
}

while($row = mysqli_fetch_array($cols)){
    $column_result[] = $row['Field'];
}
if(isset($_POST['Add']) && $_POST['Add']=='Add'){
	if ($param == 'student')
	{
		$student_number =  test_input($_POST['student_number']);
        $name = test_input($_POST['name']);
        $class =  test_input($_POST['class']);
        $major = test_input($_POST['major']);

        $check_query = "SELECT * FROM student WHERE student_number=$student_number";
        if($student_number=='' || $name=='' || $class=='' || $major==''){
        	$err_msg = 'Please fill all the fields';
        }else if(!is_numeric($student_number)){
        	$err_msg = 'Student number should contain only numbers';
        }else if(!is_numeric($class)){
        	$err_msg = 'Class should contain only numbers';
        }else if(!ctype_alpha($major)){
        	$err_msg = 'Class should contain only alphabets';
        }else if(getCount($con, $check_query)>0){
        	$err_msg = 'Student number already exists';
        }
         
        $sql = "INSERT INTO student VALUES ('$student_number',
            '$name','$class','$major')";
	}
	else if ($param == 'course')
	{
		$course_number =  test_input($_POST['course_number']);
        $course_name = test_input($_POST['course_name']);
        $credit_hours =  test_input($_POST['credit_hours']);
        $department = test_input($_POST['department']);

        $check_query = "SELECT * FROM course WHERE course_number='$course_number'";
        if($course_number=='' || $course_name=='' || $credit_hours=='' || $department==''){
        	$err_msg = 'Please fill all the fields';
        }else if(!is_numeric($credit_hours)){
        	$err_msg = 'Credit hours should contain only numbers';
        }else if(getCount($con, $check_query)>0){
        	$err_msg = 'Course number already exists';
        }

        $sql = "INSERT INTO course VALUES ('$course_number',
            '$course_name','$credit_hours','$department')";
	}
	else if ($param == 'section')
	{
		$section_identifier =  test_input($_POST['section_identifier']);
        $course_number = test_input($_POST['course_number']);
        $semester = test_input($_POST['semester']);
        $year =  test_input($_POST['year']);
        $instructor = test_input($_POST['instructor']);
         
        $check_query = "SELECT * FROM section WHERE section_identifier='$section_identifier'";
        $check_query_foreign_key = "SELECT * FROM course WHERE course_number='$course_number'";
        if($section_identifier=='' || $course_number=='' || $semester=='' || $year=='' || $instructor==''){
        	$err_msg = 'Please fill all the fields';
        }else if(!is_numeric($section_identifier)){
        	$err_msg = 'Section identifier should contain only numbers';
        }else if(getCount($con, $check_query)>0){
        	$err_msg = 'Section identifier already exists';
        }else if(getCount($con, $check_query_foreign_key)==0){
        	$err_msg = 'Course number doesn\'t exist';
        }

        $sql = "INSERT INTO section VALUES ('$section_identifier',
            '$course_number','$semester','$year','$instructor')";
	}
	else if ($param == 'grade_report')
	{
		$student_number =  test_input($_POST['student_number']);
        $section_identifier = test_input($_POST['section_identifier']);
        $grade =  test_input($_POST['grade']);
        
        $check_query_foreign_key1 = "SELECT * FROM course WHERE course_number='$course_number'";
        $check_query_foreign_key2 = "SELECT * FROM course WHERE course_number='$course_number'";
        if($student_number=='' || $section_identifier=='' || $grade==''){
        	$err_msg = 'Please fill all the fields';
        }else if(!is_numeric($section_identifier)){
        	$err_msg = 'Section identifier should contain only numbers';
        }else if(!is_numeric($section_identifier)){
        	$err_msg = 'Section identifier should contain only numbers';
        }else if(getCount($con, $check_query_foreign_key1)==0){
        	$err_msg = 'Section identifier already exists';
        }else if(getCount($con, $check_query_foreign_key2)==0){
        	$err_msg = 'Course number doesn\'t exist';
        }

        $sql = "INSERT INTO grade_report  VALUES ('$student_number',
            '$section_identifier','$grade')";
	}
	else if ($param == 'prerequisite')
	{
		$course_number =  test_input($_POST['course_number']);
        $prerequisite_number = test_input($_POST['prerequisite_number']);
        
        if($course_number=='' || $prerequisite_number==''){
        	$err_msg = 'Please fill all the fields';
        }

        $sql = "INSERT INTO prerequisite VALUES ('$course_number',
            '$prerequisite_number')";
	}
	
	if($err_msg==''){
		mysqli_query($con,$sql);
		closedbconnection($con);
		header('Location:'. SITEURL."?tab=". $param);
		exit;
	}	
}
           
$result     =   getAllRows(mysqli_query($con,"SELECT * from ". $param ));
closedbconnection($con);
?>
		<div class = "tabs">
			<div class ="tabs__sidebar">
				<a href="<?php echo SITEURL;?>?tab=student" class="<?php  echo ($param=='student')?'active_tab':''; ?>">Student</a>&nbsp;
				<a href="<?php echo SITEURL;?>?tab=course" class="<?php  echo ($param=='course')?'active_tab':''; ?>">Course</a>&nbsp;
				<a href="<?php echo SITEURL;?>?tab=section" class="<?php  echo ($param=='section')?'active_tab':''; ?>">Section</a>&nbsp;
				<a href="<?php echo SITEURL;?>?tab=grade_report" class="<?php  echo ($param=='grade_report')?'active_tab':''; ?>">Grade</a>&nbsp;
				<a href="<?php echo SITEURL;?>?tab=prerequisite" class="<?php  echo ($param=='prerequisite')?'active_tab':''; ?>">Prerequisite</a>
		    </div>
		    <div>
		    	<table>
		    		<thead>
		    			<tr>
		    				<?php foreach( $column_result as $header){?>
		    				 	<th><?php  echo $header ;?> </th>
		    				<?php } ?>
						</tr>
		    		</thead>
		    		<tbody>
		    			<?php foreach ($result as $key => $value) {?> 
			  				<tr id="row_id_<?php  echo $key?>">
			    				<?php foreach($column_result as $header){?>
			    				 	<td class="<?php echo (in_array($header, $primary_keys))?'primary_key':'';?>">
			    				 		<span class="col_data">
			    				 			<?php echo $value->$header;?>
			    				 		</span> 
			    				 		<span class="col_input">
			    				 			<input type="text" name="<?php echo $header;?>" value="<?php echo $value->$header;?>">
			    				 			<?php if(in_array($header, $primary_keys)){?>
			    				 			<input name="header" type="hidden" value="<?php echo $header;?>">
			    				 			<input name="column" type="hidden" value="<?php echo $value->$header;?>">
			    				 		<?php }?>
			    				 		</span>
			    				 	</td>
			    				<?php } ?>
			    				<td>
			    					<input type ="button" class="col_edit" value ="Edit" onClick="editRow(<?php echo $key?>)">
			    					<input type ="button" class="col_update" value ="Update" onClick="onUpdate('<?php echo $param;?>',<?php echo $key;?>)">
			    				</td>
							</tr>
						<?php }?>
					</tbody>
					<tfoot>
						<tr class="error_row">
							<td style="border-top: 2px solid #000;" colspan="<?php echo count($column_result)+1;?>">
								<?php echo ($err_msg!='')?$err_msg:'';?>
							</td>
						</tr>
						<tr class="add_row">
							<form name="addForm" action="" method="post">
								<?php foreach($column_result as $header){?>
				    		    	<td>
				    		    		<input type="text" name="<?php echo $header;?>"> 
				    		        </td>
				    			<?php } ?>
				    			<td>
				    				<input type="submit" name="Add" value ="Add">
				    			</td>
				    		</form>
						</tr>
					</tfoot>
		    	</table>
		    </div>
		</div>
	</body>
</html>